<h1 align="left">Repository for SIH 2024 💻</h1>

###

<h3 align="left">Topic - Centralized Automated Solution for Price Estimation & Reasonability.</h3>

###

<p align="left">This is a repository for the Smart India Hackathon 2024.<br><br>It contains:<br>- Required files for SIH 2024<br>- Previous versions of the files for backup</p>

###

<h3 align="left">Languages and Libraries used</h3>

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="40" alt="python logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jupyter/jupyter-original.svg" height="40" alt="jupyter logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sqlite/sqlite-original.svg" height="40" alt="sqlite logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" height="40" alt="html5 logo"  />
</div>

###
