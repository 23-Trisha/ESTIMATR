isntance folder in the hackathon project
